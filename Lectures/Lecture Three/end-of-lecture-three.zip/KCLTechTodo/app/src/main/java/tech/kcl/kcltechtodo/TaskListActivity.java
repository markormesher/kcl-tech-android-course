package tech.kcl.kcltechtodo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class TaskListActivity extends AppCompatActivity {

    // view components
    private ProgressBar loadingIcon;
    private ListView listView;
    private TextView noTasksMessage;

	/*================*
     * Activity setup *
	 *================*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // set the layout of this activity
        setContentView(R.layout.activity_task_list);

        // set the string for the title bar
        setTitle(getString(R.string.task_list_activity_title));

        // find UI components
        loadingIcon = (ProgressBar) findViewById(R.id.loading_icon);
        listView = (ListView) findViewById(R.id.list_view);
        noTasksMessage = (TextView) findViewById(R.id.no_tasks_message);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.task_list_activity_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.create_task:
                startActivity(new Intent(TaskListActivity.this, EditTaskActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}