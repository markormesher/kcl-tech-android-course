package tech.kcl.kcltechtodo;

import android.opengl.Visibility;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class TaskListActivity extends AppCompatActivity {

    private ProgressBar loadingIcon;
    private TextView noTasksMessage;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_task_list);

        // find UI components
        loadingIcon = (ProgressBar) findViewById(R.id.loading_icon);
        noTasksMessage = (TextView) findViewById(R.id.no_tasks_message);
        listView = (ListView) findViewById(R.id.list_view);

        // create some data for our adapter
        String[] data = new String[]{"ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "ordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis"};

        // create an instance of the adapter
        BuildXNameAdapter adapter = new BuildXNameAdapter(this, data);

        // connect the ListView and the adapter
        listView.setAdapter(adapter);

        // hide/show views
        loadingIcon.setVisibility(View.GONE);
        listView.setVisibility(View.VISIBLE);
    }
}









