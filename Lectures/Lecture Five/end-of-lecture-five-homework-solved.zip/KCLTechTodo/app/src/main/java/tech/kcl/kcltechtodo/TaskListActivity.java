package tech.kcl.kcltechtodo;

import android.content.SharedPreferences;
import android.opengl.Visibility;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.joda.time.DateTime;

import java.util.ArrayList;

public class TaskListActivity extends AppCompatActivity {

    private ProgressBar loadingIcon;
    private TextView noTasksMessage;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_task_list);

        // find UI components
        loadingIcon = (ProgressBar) findViewById(R.id.loading_icon);
        noTasksMessage = (TextView) findViewById(R.id.no_tasks_message);
        listView = (ListView) findViewById(R.id.list_view);

        // create some data for our adapter
        String[] data = new String[]{"ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "ordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis", "ana", "victor", "jordan", "ALAN!!!", "steve", "mark", "carmichael", "richard", "sarah", "casey", "willis"};

        // create an instance of the adapter
        BuildXNameAdapter adapter = new BuildXNameAdapter(this, data);

        // connect the ListView and the adapter
        listView.setAdapter(adapter);

        // hide/show views
        loadingIcon.setVisibility(View.GONE);
        listView.setVisibility(View.VISIBLE);

        /*****************
         DEMO: PREFERENCES
         *****************/

        // get a reference to the preferences object
        SharedPreferences prefs =
                PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        // start an editor, to write some new values
        SharedPreferences.Editor editor = prefs.edit();

        // write in three values
        editor.putInt("user_highscore", 9001);
        editor.putBoolean("welcome_tour_finished", true);
        editor.putString("notification_alert_sound", "bells");

        // save our changes - this is important!
        editor.apply();

        // read the values back, by specifying a key and a default
        int highScore = prefs.getInt("user_highscore", 0);
        boolean tourFinished = prefs.getBoolean("welcome_tour_finished", false);
        String alertSound = prefs.getString("notification_alert_sound", "default");

        // try to read something unknown, and get the default value
        String somethingElse = prefs.getString("unknown_key", "default value");

        /*********************
         DEMO: DATABASE INSERT
         *********************/

        // create three incomplete tasks
        Task task1 = new Task("Buy milk", "The green stuff", DateTime.now(), false);
        Task task2 = new Task("Buy bread", "Wholemeal bro!", DateTime.now(), false);
        Task task3 = new Task("Buy tickets", "", DateTime.now(), false);

        // get a new instance of our database helper
        DbHelper dbHelper = new DbHelper(this);

        // save all of these tasks in the database
        dbHelper.saveTask(task1);
        dbHelper.saveTask(task2);
        dbHelper.saveTask(task3);

        /*******************
         DEMO: DATABASE READ
         *******************/

        // read all of our tasks
        ArrayList<Task> tasks = dbHelper.getIncompleteTasks();

        // loop through them to do something with them
        for (Task t : tasks) {
            // do something with them
            Log.d("KCL_TECH_TODO", t.getId() + ": " + t.getTitle());
        }

    }
}









