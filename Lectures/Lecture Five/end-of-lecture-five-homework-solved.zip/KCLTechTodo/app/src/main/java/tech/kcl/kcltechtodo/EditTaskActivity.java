package tech.kcl.kcltechtodo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class EditTaskActivity extends AppCompatActivity {

    // view components
    private ProgressBar loadingIcon;
    private ViewGroup mainContent;
    private EditText titleInput;
    private DatePicker dueDateInput;
    private EditText notesInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // set the layout of this activity
        setContentView(R.layout.activity_edit_task);

        // TODO: set the string for the title bar

        // find UI components
        loadingIcon = (ProgressBar) findViewById(R.id.loading_icon);
        mainContent = (ViewGroup) findViewById(R.id.main_content);
        titleInput = (EditText) findViewById(R.id.title_input);
        dueDateInput = (DatePicker) findViewById(R.id.due_date_input);
        notesInput = (EditText) findViewById(R.id.notes_input);
        Button saveButton = (Button) findViewById(R.id.save_button);

        // set up the date picker
        dueDateInput.setCalendarViewShown(false);

        // switch to the form view from the loading view
        loadingIcon.setVisibility(View.GONE);
        mainContent.setVisibility(View.VISIBLE);
    }

}
