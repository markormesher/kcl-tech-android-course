package tech.kcl.kcltechtodo;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

public class BuildXNameAdapter extends BaseAdapter {

    private Activity activity;
    private String[] data;

    public BuildXNameAdapter(Activity activity, String[] data) {
        this.activity = activity;
        this.data = data;
    }

    public void setData(String[] data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (data == null) return 0;
        return data.length;
    }

    @Override
    public Object getItem(int position) {
        if (data == null) return null;
        return data[position];
    }

    // this method is rarely useful, so we're ignoring it
    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View recycledView, ViewGroup parent) {
        // try to use the recycled view, if there is one
        View output = recycledView;
        if (output == null) {
            // there wasn't a recycled view to work with, so create one from scratch
            LayoutInflater inflater = activity.getLayoutInflater();
            output = inflater.inflate(R.layout.list_view_row, parent, false);
        }

        // get hold of the TextView
        TextView textView = (TextView) output.findViewById(R.id.name);

        // get the name to display
        String name = (String) getItem(position);

        // put the name in the TextView
        textView.setText(name);

        return output;
    }
}





















