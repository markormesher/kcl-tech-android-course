package tech.kcl.kcltechtodo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.Currency;

public class DbHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "DB";
    public static final int DB_VERSION = 1;

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create the table by "upgrading" from version zero (i.e. no database) to the current version
        onUpgrade(db, 0, DB_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        switch (oldVersion) {
            case 0:
                // create the initial database
                db.execSQL("CREATE TABLE Tasks (" +
                        "id INTEGER PRIMARY KEY," +
                        "title TEXT," +
                        "notes TEXT," +
                        "due_date INTEGER," +
                        "is_complete INTEGER" +
                        ");");

            case 1:
                // upgrade from 1 to 2 (not used yet)

            case 2:
                // upgrade from 2 to 3 (not used yet)

            case 3:
                // upgrade from 3 to 4 (not used yet)

                // etc..

                break;

            default:
                throw new IllegalArgumentException();
        }
    }

    /**
     * Save a single task in the database, inserting or updating based on the primary key.
     *
     * @param t the task to insert
     */
    public void saveTask(Task t) {
        // get a writable instance of the database
        SQLiteDatabase db = getWritableDatabase();
        if (db == null) return;

        // insert the task
        db.insertWithOnConflict(
                "Tasks",                            // the table name
                null,                               // ignore this
                t.getContentValues(),               // a ContentValues representation of our task
                SQLiteDatabase.CONFLICT_REPLACE     // the conflict resolver to use: replace
        );
    }

    /**
     * Gets a list of all incomplete tasks.
     *
     * @return a (possibly empty) list of tasks
     */
    public ArrayList<Task> getIncompleteTasks() {
        // create an empty ArrayList to build our output
        ArrayList<Task> output = new ArrayList<>();

        // get a readable instance of the database
        SQLiteDatabase db = getReadableDatabase();
        if (db == null) return output;

        // run the query to get all incomplete tasks
        Cursor rawTasks = db.rawQuery("SELECT * FROM Tasks WHERE is_complete = 0 ORDER BY due_date ASC;", null);

        // move the cursor to the first result (or skip this section if there are no results)
        if (rawTasks.moveToFirst()) {
            // iterate through results
            do {
                // convert the cursor version of the task to a real Task object and add it to output
                output.add(new Task(rawTasks));
            } while (rawTasks.moveToNext());
        }

        // we're done with the cursor and database, so we can close them here
        rawTasks.close();
        db.close();

        // return the (possibly empty) list
        return output;
    }

    /**
     * Returns a task for a specific ID, or null if one could not be found.
     *
     * @param id the ID to search for
     * @return the task found, or null
     */
    @Nullable
    public Task getTask(int id) {
        // "holder" for our output, which starts as null
        Task output = null;

        // get a readable instance of the database
        SQLiteDatabase db = getReadableDatabase();
        if (db == null) return null;

        // run the query to get the matching task
        Cursor rawTask = db.rawQuery("SELECT * FROM Tasks WHERE id = ? ORDER BY due_date ASC;", new String[]{String.valueOf(id)});

        // move the cursor to the first result, if one exists
        if (rawTask.moveToFirst()) {
            // convert the cursor to a task and assign it to our output
            output = new Task(rawTask);
        }

        // we're done with the cursor and database, so we can close them here
        rawTask.close();
        db.close();

        // return the (possibly null) output
        return output;
    }
}
