package tech.kcl.kcltechtodo;

import android.content.ContentValues;
import android.database.Cursor;

import org.joda.time.DateTime;

import java.util.Currency;

public class Task {

    private int id = -1; // ID defaults to -1, meaning "no ID has been set yet"
    private String title;
    private String notes;
    private DateTime dueDate;
    private boolean isComplete;

    /**
     * Create a new Task by passing the title, notes, due date and completion status.
     *
     * @param title      the title
     * @param notes      the notes
     * @param dueDate    the due date
     * @param isComplete the completion status
     */
    public Task(String title, String notes, DateTime dueDate, boolean isComplete) {
        this.title = title;
        this.notes = notes;
        this.dueDate = dueDate;
        this.isComplete = isComplete;
    }

    /**
     * Create a new Task by passing a Cursor the represents a task object.
     *
     * @param input a database Cursor from the Tasks table
     */
    public Task(Cursor input) {
        id = input.getInt(input.getColumnIndex("id"));
        title = input.getString(input.getColumnIndex("title"));
        notes = input.getString(input.getColumnIndex("notes"));
        dueDate = new DateTime(input.getInt(input.getColumnIndex("due_date")));
        isComplete = input.getInt(input.getColumnIndex("is_complete")) == 1;
    }

    /**
     * Converts the Task object into a ContentValues object that can be inserted into the database.
     *
     * @return a ContentValues object for database insertion
     */
    public ContentValues getContentValues() {
        // build a new ContentValues to work with
        ContentValues output = new ContentValues();

        // add the ID only if it has been set
        if (id > 0) output.put("id", id);

        // add other attributes/properties
        output.put("title", title);
        output.put("notes", notes);
        output.put("due_date", dueDate.getMillis());
        output.put("is_complete", isComplete ? 1 : 0);

        // return the finished set
        return output;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getNotes() {
        return notes;
    }

    public DateTime getDueDate() {
        return dueDate;
    }

    public boolean isComplete() {
        return isComplete;
    }
}
