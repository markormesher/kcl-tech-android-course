package tech.kcl.api_example;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.widget.TextView;

import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        outputLine("KCL Tech Build X: Android");
        outputLine("Lecture Seven");
        outputLine("Networking and APIs");
        outputLine("--");

        // put your code here!

        outputLine("Request started...");
        new ApiRequest().execute("http://api.worldbank.org/countries/?format=json&per_page=300");

    }

    private class ApiRequest extends AsyncTask<String, Double, JSONArray> {

        @Override
        protected JSONArray doInBackground(String... params) {
            // check input
            if (params.length != 1) return null;

            try {
                // open connection
                URL url = new URL(params[0]);
                InputStream inStream = url.openStream();
                DataInputStream dataInStream = new DataInputStream(inStream);

                // buffer to hold chunks as they are read
                byte[] buffer = new byte[1024];
                int bufferLength;

                // string builder to hold output
                ByteArrayOutputStream output = new ByteArrayOutputStream();

                // read from stream
                while ((bufferLength = dataInStream.read(buffer)) > 0) {
                    output.write(buffer, 0, bufferLength);
                }

                // convert to JSON array
                return new JSONArray(output.toString("UTF-8"));
            } catch (Exception e) {
                // something went wrong
                outputLine("Something went wrong!");
                return null;
            }
        }

        @Override
        protected void onPostExecute(JSONArray result) {
            // check result
            if (result == null) return;

            try {
                // navigate through data
                JSONArray countryList = result.getJSONArray(1);
                JSONObject country;
                for (int i = 0; i < countryList.length(); ++i) {
                    country = countryList.getJSONObject(i);
                    outputLine(country.getString("name"));
                }
            } catch (Exception e) {
                // something went wrong
                outputLine("Something went wrong!");
            }
        }
    }

    /*-------------------------*
     | You don't need to touch |
     |   the code down here!   |
     *-------------------------*/

    private TextView outputView;
    private String output = "";

    protected void init() {
        outputView = (TextView) findViewById(R.id.output);
    }

    protected void clearOutput() {
        output = "";
        outputView.setText("");
    }

    protected void outputLine(String s) {
        output += (new DateTime()).toString("HH:mm:ss") + " <strong>" + s + "</strong><br />";
        outputView.setText(Html.fromHtml(output));
    }
}
