package tech.kcl.notificationdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BasicNotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_notification);

        // get the buttons
        Button clickForGcmRegistration = (Button) findViewById(R.id.click_to_register_gcm);
        Button clickForNotification = (Button) findViewById(R.id.click_for_notification);

        // attach a click listener to the GCM button
        clickForGcmRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // go to the GCM registration activity
                startActivity(new Intent(BasicNotificationActivity.this, RegisterForGcmActivity.class));
            }
        });

        // attach a click listener to the notification button
        clickForNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // this code will run each time the button is clicked

                // TODO: show a notification to the user
            }
        });
    }
}