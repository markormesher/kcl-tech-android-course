package tech.kcl.notificationdemo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

public class RegisterForGcmActivity extends AppCompatActivity {

    /*
     * You don't need to edit this file.
     * It's the registration system for GCM.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_for_gcm);

        // check whether play services are available
        final int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);

        // failure?
        if (resultCode != ConnectionResult.SUCCESS) {
            // show failure error
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this, 9000).show();
            }

            // give up
            finish();
            return;
        }

        // check for an existing name
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(RegisterForGcmActivity.this);
        String currentName = prefs.getString("gcm_name", null);
        if (currentName != null) {
            Toast.makeText(this, "Already registered as '" + currentName + "'", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // create a dialog pop-up
        final EditText editText = new EditText(this);
        editText.setHint("Enter your name");
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Register for GCM");
        builder.setView(editText);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // get name
                String name = editText.getText().toString().trim();
                if (name.length() == 0) {
                    Toast.makeText(RegisterForGcmActivity.this, "No name entered", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                // register for GCM
                new GcmRegistrationTask().execute(name);
            }
        });
        builder.setCancelable(false);

        // launch dialog
        builder.create().show();
    }

    @Override
    public void onBackPressed() {
        // block attempts to go back
        return;
    }

    private class GcmRegistrationTask extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String... input) {
            String name = input[0];

            try {
                // register for ID
                GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(RegisterForGcmActivity.this);
                gcm.unregister();
                String registrationId = gcm.register("171114275809");
                if (registrationId == null) return false;

                // send to API
                URL url = new URL("http://gcmdemo.markormesher.co.uk/register");
                Map<String, Object> params = new LinkedHashMap<>();
                params.put("name", name);
                params.put("address", registrationId);
                StringBuilder postData = new StringBuilder();
                for (Map.Entry<String, Object> param : params.entrySet()) {
                    if (postData.length() != 0) postData.append('&');
                    postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
                    postData.append('=');
                    postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
                }
                byte[] postDataBytes = postData.toString().getBytes("UTF-8");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
                conn.setDoOutput(true);
                conn.getOutputStream().write(postDataBytes);
                Reader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                for (int c = in.read(); c != -1; c = in.read())
                    System.out.print((char) c);

                // store in preferences
                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(RegisterForGcmActivity.this).edit();
                editor.putString("gcm_name", name);
                editor.apply();

                // done
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(RegisterForGcmActivity.this, "Done!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(RegisterForGcmActivity.this, "Failed!", Toast.LENGTH_SHORT).show();
            }
            finish();
        }
    }
}
