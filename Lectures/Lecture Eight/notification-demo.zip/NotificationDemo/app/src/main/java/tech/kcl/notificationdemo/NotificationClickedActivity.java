package tech.kcl.notificationdemo;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NotificationClickedActivity extends AppCompatActivity {

    /*
     * You don't need to edit this file.
     * It's a simple activity that opens whenever a notification is clicked.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_clicked);

        // get message from bundle extras
        String message = "There was no message sent";
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("message")) {
            message = extras.getString("message");
        }

        // set output
        TextView messageView = (TextView) findViewById(R.id.message);
        messageView.setText(getString(R.string.notification_click_message, message));

        // set close listener
        Button close = (Button) findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}