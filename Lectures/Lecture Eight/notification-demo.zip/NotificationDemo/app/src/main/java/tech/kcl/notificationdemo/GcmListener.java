package tech.kcl.notificationdemo;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.gcm.GcmListenerService;

import org.json.JSONException;
import org.json.JSONObject;

public class GcmListener extends GcmListenerService {

    /*
     * This service is set up to listen for any push notifications from GCM.
     * When one is received, the method onMessageReceived(...) will be called.
     */

    @Override
    public void onMessageReceived(String from, Bundle data) {
        // check data
        if (data == null) return;

        // get data
        long id = Long.parseLong(data.getString("id", "0"));
        String title = data.getString("title");
        String text = data.getString("text");

        // TODO: use the id, title and text fields however you like!
        Log.d("GCM-DEMO", "Id: " + id);
        Log.d("GCM-DEMO", "Title: " + title);
        Log.d("GCM-DEMO", "Text: " + text);
    }
}
