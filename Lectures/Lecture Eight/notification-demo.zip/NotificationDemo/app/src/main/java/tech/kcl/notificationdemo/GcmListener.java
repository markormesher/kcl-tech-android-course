package tech.kcl.notificationdemo;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;

import com.google.android.gms.gcm.GcmListenerService;

import org.json.JSONException;
import org.json.JSONObject;

public class GcmListener extends GcmListenerService {

    /*
     * This service is set up to listen for any push notifications from GCM.
     * When one is received, the method onMessageReceived(...) will be called.
     */

    @Override
    public void onMessageReceived(String from, Bundle data) {
        // check data
        if (data == null) return;
        if (!data.containsKey("payload")) return;

        // get data
        JSONObject payload;
        int id;
        String title, text;
        try {
            payload = new JSONObject(data.getString("payload"));
            id = payload.getInt("id");
            title = payload.getString("title");
            text = payload.getString("text");
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        // TODO: use the id, title and text fields however you like!
    }
}
