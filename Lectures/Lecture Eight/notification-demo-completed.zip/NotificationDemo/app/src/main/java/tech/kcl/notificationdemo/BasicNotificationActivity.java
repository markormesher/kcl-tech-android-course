package tech.kcl.notificationdemo;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class BasicNotificationActivity extends AppCompatActivity {

    private int notificationId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_notification);

        // get the buttons
        Button clickForGcmRegistration = (Button) findViewById(R.id.click_to_register_gcm);
        Button clickForNotification = (Button) findViewById(R.id.click_for_notification);

        // attach a click listener to the GCM button
        clickForGcmRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // go to the GCM registration activity
                startActivity(new Intent(BasicNotificationActivity.this, RegisterForGcmActivity.class));
            }
        });

        // attach a click listener to the notification button
        clickForNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // this code will run each time the button is clicked

                // increment the ID
                ++notificationId;

                // create a notification
                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(BasicNotificationActivity.this)
                                .setContentTitle("This is notification #" + notificationId)
                                .setContentText("This is the text!")
                                .setAutoCancel(true)
                                .setSmallIcon(R.drawable.kcl_tech_logo)
                                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.kcl_tech_logo))
                                .setVibrate(new long[]{500, 500, 200, 500})
                                .setLights(0xff00ff00, 500, 200);

                // create an action to complete when the notification is clicked
                Intent intent = new Intent(BasicNotificationActivity.this, NotificationClickedActivity.class);
                intent.putExtra("message", "You clicked notification #" + notificationId);
                PendingIntent pendingIntent = PendingIntent.getActivity(BasicNotificationActivity.this, notificationId, intent, PendingIntent.FLAG_CANCEL_CURRENT);

                // set the action on the notification
                builder.setContentIntent(pendingIntent);

                // get the notification manager
                NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                // send the notification
                manager.notify(notificationId, builder.build());
            }
        });
    }
}