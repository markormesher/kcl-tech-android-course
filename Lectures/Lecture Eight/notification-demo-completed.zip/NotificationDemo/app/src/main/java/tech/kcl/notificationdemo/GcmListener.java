package tech.kcl.notificationdemo;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;

import com.google.android.gms.gcm.GcmListenerService;

import org.json.JSONException;
import org.json.JSONObject;

public class GcmListener extends GcmListenerService {

    /*
     * This service is set up to listen for any push notifications from GCM.
     * When one is received, the method onMessageReceived(...) will be called.
     */

    @Override
    public void onMessageReceived(String from, Bundle data) {
        // check data
        if (data == null) return;
        if (!data.containsKey("payload")) return;

        // get data
        JSONObject payload;
        int id;
        String title, text;
        try {
            payload = new JSONObject(data.getString("payload"));
            id = payload.getInt("id");
            title = payload.getString("title");
            text = payload.getString("text");
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        // create a notification
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this)
                        .setContentTitle(title)
                        .setContentText(text)
                        .setAutoCancel(true)
                        .setSmallIcon(R.drawable.kcl_tech_logo)
                        .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.kcl_tech_logo))
                        .setVibrate(new long[]{500, 500, 200, 500})
                        .setLights(0xff00ff00, 500, 200);

        // create an action to complete when the notification is clicked
        Intent intent = new Intent(this, NotificationClickedActivity.class);
        intent.putExtra("message", text);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, id, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        // set the action on the notification
        builder.setContentIntent(pendingIntent);

        // get the notification manager
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // send the notification
        manager.notify(id, builder.build());
    }
}
